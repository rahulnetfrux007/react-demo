import React, { useState } from 'react'

const LoginForm = props => {
  const initialFormState = { name: '', Password: '' }
  const [user, setUser] = useState(initialFormState)

  const handleInputChange = event => {
    const { name, value } = event.target

    setUser({ ...user, [name]: value })
  }

  return (
    <form
      onSubmit={event => {
        event.preventDefault()
        if (!user.name || !user.Password) {
			alert("Fill required field information");
			return}

        props.addUser(user)
        setUser(initialFormState)
      }}
    >
      <label>Name</label>
      <input type="text" name="name" value={user.name} onChange={handleInputChange} />
      <label>Password</label>
      <input type="password" name="Password" value={user.Password} onChange={handleInputChange} />
      <button className="btn btn-default">Login</button>
    </form>
  )
}

export default LoginForm