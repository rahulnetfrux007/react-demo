import React, { useState } from 'react'

const EditUserForm = props => {
  const [user, setUser] = useState(props.currentUser)

  const handleInputChange = event => {
    const { name, value } = event.target

    setUser({ ...user, [name]: value })
  }

  return (
    <form
      onSubmit={event => {
        event.preventDefault()

        props.updateUser(user.id, user)
      }}
    >
      <label>Name</label>
      <input type="text" name="name" value={user.name} onChange={handleInputChange} />
	  <label>Phone Number</label>
      <input type="text" name="phone" value={user.phone} onChange={handleInputChange} />
      <label>Address</label>
      <input type="text" name="Address" value={user.Address} onChange={handleInputChange} />
      <button className="btn btn-default">Update user</button>
      <button onClick={() => props.setEditing(false)} className="button muted-button btn">
        Cancel
      </button>
    </form>
  )
}

export default EditUserForm