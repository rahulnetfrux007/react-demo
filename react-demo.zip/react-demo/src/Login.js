import React from 'react' 
import ReactDOM from 'react-dom'
import './index.css'
import App from './App' 
import LoginForm  from './forms/LoginForm'
import UserProfile from './UserProfile'
const Login = () => { 
	const addUser= user =>{
	  // Make web api call to authenticate user from database 
	  if((user.name==="Admin" || user.name==="admin" ) && (user.Password==="Admin"|| user.Password==="admin"))
	  {
	  //alert("Successfully logged in");  
	  UserProfile.setName(user.name)
	  ReactDOM.render(<App />, document.getElementById('root'))
	  }
	  else
	  {
		alert("!Please enter correct username and password");   
	  } 
	}
	return(
	<div>
			  <h1 className="header">Login</h1>
			  <br />
			  <LoginForm addUser={addUser} />
			</div>
	)
}
export default Login