import React, { useState } from 'react'
import UserTable from './tables/UserTable'
import AddUserForm  from './forms/AddUserForm'
import EditUserForm from './forms/EditUserForm'
//import UserProfile from './UserProfile'
const App = () => {
	
  //Set usersData data from Web Api call
  const usersData = [
    { id: 1, name: 'Tania',phone:'xxxxxxx785', Address: '402 - Swarna Jayanti Sadan Deluxe, Dr. B.D. Marg, New Delhi 110001' },
    { id: 2, name: 'Craig',phone:'xxxxxxx783', Address: '4, Ferozeshah Road, New Delhi 110013' },
    { id: 3, name: 'Ben',phone:'xxxxxxx789', Address: 'Bunglow No.9, Teen Murti Lane, New Delhi 110011' },
  ]
  //UserProfile.setName("surendra Singh");
  //alert(UserProfile.getName());
  const [users, setUsers] = useState(usersData)
  const addUser= user =>{
	  // Make web api call to add new user to database
	  user.id=users.length+1
	  setUsers([...users,user])
  }
  const deleteUser = id => {
  //Make web api call to delete user from database
  setUsers(users.filter(user => user.id !== id))
  }
  const [editing, setEditing] = useState(false)
  const initialFormState = { id: null, name: '', Address: '',phone:'' }
  const [currentUser, setCurrentUser] = useState(initialFormState)
  const editRow = user => {
  setEditing(true)

  setCurrentUser({ id: user.id, name: user.name, Address: user.Address,phone:user.phone })
  }
  const updateUser = (id, updatedUser) => {
  setEditing(false)
  //Make UpdateUser web api call to update json
  setUsers(users.map(user => (user.id === id ? updatedUser : user)))
}
  return (
    <div className="login-container">
      <h1 className="header">React App with CRUD Operation</h1>
      <div className="flex-row">
        <div className="flex-large">
		  {editing ? (
			<div>
			  <h2 className="sub-header">Edit user</h2>
			  <EditUserForm
				editing={editing}
				setEditing={setEditing}
				currentUser={currentUser}
				updateUser={updateUser}
			  />
			</div>
		  ) : (
			<div>
			  <h2 className="sub-header">Add user</h2>
			  <AddUserForm addUser={addUser} />
			</div>
		  )}
		</div>
        <div className="flex-large">
          <h2 className="sub-header">View users</h2>
          <UserTable users={users} editRow={editRow} deleteUser={deleteUser} />
        </div>
      </div>
    </div>
  )
}
export default App