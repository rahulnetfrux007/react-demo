import React from 'react'

const UserTable = props => (
  <div className="table-container"><table>
    <thead>
      <tr>
        <th>Name</th>
		<th>Phone Number</th>
        <th>Address</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
	{props.users.length>0?(
	props.users.map(user=> (
	<tr key={user.id}>
        <td>{user.name}</td>
		<td>{user.phone}</td>
        <td>{user.Address}</td>
        <td>
          <button
  onClick={() => {
    props.editRow(user)
  }}
  className="btn btn-default button muted-button"
>
  Edit
</button>
          <button onClick={() => props.deleteUser(user.id)} className="btn button muted-button">Delete</button>
        </td>
      </tr>
	))
	):
	(
	<tr>
        <td colSpan={3}>No data found</td>
	</tr>
	) 
	}
      
    </tbody>
  </table></div>
)

export default UserTable