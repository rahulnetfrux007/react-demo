import React from 'react'
import ReactDOM from 'react-dom'
import './index.css'
import App from './App'
import Login from './Login'
import UserProfile from './UserProfile'
//UserProfile.setName("surendra Singh");
  //alert(UserProfile.getName());
if(UserProfile.getName()!=="")
{
   ReactDOM.render(<App />, document.getElementById('root'))
}
else
{
  ReactDOM.render(<Login />, document.getElementById('root'))
}